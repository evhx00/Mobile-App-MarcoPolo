package android.bignerdranch.marcopolo;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button mMarco_button, mPolo_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mMarco_button = (Button) findViewById(R.id.marco_button);
        mPolo_button = (Button) findViewById(R.id.polo_button);

        // True Button Listener
        mMarco_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Code to execute on button click goes here.
                Toast.makeText(MainActivity.this,
                        R.string.marco,
                        Toast.LENGTH_SHORT).show();
            }
        });

        //False Button Listener
        mPolo_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Code to execute on button click goes here.
                Toast.makeText(MainActivity.this,
                        R.string.polo,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}